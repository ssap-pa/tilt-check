# Demo: "Why my to-do app has three buttons" (about 40 seconds)

Backgrounds in ./bg: desk.png, notebook.png, park.png. Cast: Sam (draw_person) and Tick (draw_tick).

## 1. hook  [bg: desk]
NARRATION: I deleted twelve buttons from my app. Sign-ups doubled. Here's what the three that survived do.
ACTION: twelve tags pop then get X-ed, three stay; Sam at the desk, surprised.
CAM: push in on the monitor, shake on the X.

## 2. three  [bg: notebook]
NARRATION: Add. Done. Snooze. Everything else was a setting nobody opened twice.
ACTION: three lines handwritten, Tick points at each.
CAM: top-down, zoom per line.

## 3. close  [bg: park]
NARRATION: The full write-up is linked below. If you ship something this week, tell me what you deleted.
ACTION: Sam and Tick on the lawn, thumbs up, end tag.
CAM: slow pull-out.
