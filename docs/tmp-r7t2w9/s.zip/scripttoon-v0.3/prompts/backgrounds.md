# Background prompt kit

Every background in the sample videos was generated with this prompt, changing only the scene sentence. Use any image model (Canva, Midjourney, DALL·E, Flux, SDXL). Ask for 16:9 and export at 1920×1080.

```
Hand-drawn black ink sketch on white paper, loose cartoon webtoon style, thick uneven pen lines, minimal shading,
mostly white with a few flat color spots. Scene: <ONE SENTENCE: the place, 3–6 objects, time of day>.
No people, no text. Wide 16:9 composition, lots of white space.
```

Scene sentences that worked:
- a small apartment room at night, a desk with two monitors showing a candlestick chart, a mug, a phone, a window with a crescent moon, an office chair
- top-down view of a wooden desk with an open blank spiral notebook in the center, a pen, a cup of tea, a small potted plant
- an empty running track at a stadium seen from the starting line, lane lines curving away, a few orange cones, empty bleachers
- a detective's desk at night with a green banker's lamp, a big magnifying glass on scattered papers, a cork board with pinned notes and red string
- an empty park lawn with open grass in the center, a swing set in the background, a tree, a bench, clouds
- a small empty shop interior from the customer side, a wooden counter with an old-fashioned cash register, empty shelves
- an empty city street at night with two large blank billboards, lampposts, closed storefronts
- a small workshop with a long empty conveyor belt across the middle, tools on the wall, cardboard boxes in a corner
- a plain hallway with three closed doors side by side, each with a small blank nameplate
- a cozy cafe corner with a small round table, two empty chairs, an open laptop and a coffee cup, a window with plants

Rules of thumb:
- Ask for the center (or the area your characters stand on) to be EMPTY. Characters are drawn on top; a busy center fights them.
- "No text": generated lettering is always wrong. Add labels with `P.tag` instead.
- Keep one or two flat colours per scene so the characters' colours stay the loudest thing on screen.

## Picking anchors
Render a grid over the image once (any 200 px grid) and write down the coordinates you will reuse: the monitor box, the counter top, door centres, the pivot of a seesaw. Put them as constants at the top of `shots.py`. The sample `shots.py` shows how.
