# Pose prompt kit (character consistency)

Upload your character sheet once and pass it as the reference image for every pose. Change only the bracketed parts.

```
The exact same cartoon character as in the reference character sheet ([NAME]: [3–6 identifying features: head shape,
hair, eyes, clothing with its text, colours]). Full body, [front view / three-quarter view / side view facing the viewer's right],
[standing / sitting on a simple office chair / lying face down], [the action: pointing to the viewer's right / both arms up /
hand on chin / running with arms pumping], [the expression: huge round eyes and a small round open mouth / eyes closed in
happy arcs and a wide smile / big tears and a wobbly frown]. Same clean thick black outlines and flat colors as the sheet.
Plain pure white background, nothing else, no text, no shadow.
```

Poses that cover most explainer videos (18): idle, typing on a laptop, thumbs up, pointing, surprised, shrug, laughing, thinking,
crying, running, lying face down, slumped on a desk, holding a blank sign, celebrating (money), plus a sidekick: wave, point,
megaphone, facepalm.

Rules
- Portrait 3:4 for standing poses, landscape 4:3 for lying/slumped. Export at the largest size your tool allows (1200×1600 works).
- Never flip a sprite that shows text on the clothing; generate the mirrored pose instead.
- Keep the white background pure: `cutout.py` keys on it. If your model adds a shadow, say "no shadow" again.
