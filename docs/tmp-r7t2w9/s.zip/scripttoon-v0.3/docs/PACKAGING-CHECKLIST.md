# Packaging checklist (what I do before every upload)

Hook (0–10 s)
- First sentence is the result, the twist or the number. Backstory comes after.
- Three or more cuts, a shake and a sound on the impact, a strong expression on the character.
- Last line of the opening promises what the viewer gets if they stay ("stay to the end for …").

Reason to stay
- Deliver the promised thing in the last shot, for real.
- Remind once around the middle ("the flip is still coming").
- End card points to the next video or the tool.

Title
- A number plus a twist or an open question. Under 60 characters, the key words in the first 40.
- Write three candidates, pick one, keep the other two in the META file.

Thumbnail (1280×720)
- 3–5 words in capitals, white outline, filling at least 40% of the frame.
- The character's face large, one strong expression (shock, tears, cheer).
- One accent colour. Check it at 320 px wide.

Description
- First two lines: the hook sentence and the main link. Then chapters. 10–15 tags.

Honesty
- No invented numbers, no invented quotes. Exaggerate the tone, never the data.
