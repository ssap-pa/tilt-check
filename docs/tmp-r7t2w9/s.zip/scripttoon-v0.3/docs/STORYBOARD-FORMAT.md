# Storyboard format

One Markdown file per video. The engine reads only two things: the shot headings and the `NARRATION:` lines. `ACTION:` and `CAM:` are notes for you (and for whoever writes `shots.py`).

```markdown
# Title of the video (ignored)

Any notes (ignored).

## 1. hook  [bg: desk]
NARRATION: One sentence the voice says. Numbers are spelled the way you want them read: "sixteen thousand", not "16,000".
ACTION: what moves, in order.
CAM: push in / pan / shake.

## 2. three  [bg: notebook]
NARRATION: ...
```

Rules
- Heading: `## <number>. <key>`. The key must exist in `SHOTS` in your shots file. Numbering drives file names (`n01.mp3`, `toon-01.mp4`) and `--shots` / `--redo`.
- One narration paragraph per shot. 5–20 seconds each. If a shot runs long, split it; the camera and props are keyed to the shot's progress `u`, so shorter shots animate tighter.
- Hook first: shots 1–3 should contain the result, the twist and the promise. Put the payoff in the last shot.
- The voice is `--voice en-US-AndrewNeural` by default (any edge-tts voice works). Narration is cached per shot in `out/toon-work/nNN.mp3`; delete the file to regenerate after editing the text.
