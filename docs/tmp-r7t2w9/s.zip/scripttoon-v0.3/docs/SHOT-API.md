# Shot API

A shot function receives `(P, u, t, L)`:
- `P` — a `Pen` bound to this frame (1920×1080). All drawing goes through it so lines "boil" like hand-drawn animation.
- `u` — progress through the narration, 0..1.
- `t` — seconds since the shot started.
- `L` — narration loudness this frame, 0..1 (drives the robot's mouth).

Timing helpers
- `seg(u, a, b)` → 0..1 progress of `u` inside `[a, b]`. Use it as the `p` of anything that pops in.
- `kf([(u0, (x,)), (u1, (x,))], u)` → smooth interpolation between keyframes (any tuple length).
- `ease`, `ease_out`, `overshoot` → curves.

Pen
- `P.line(points, width, color)`, `P.poly(points, fill)`, `P.circle(cx, cy, r, fill)`, `P.rrect(x0, y0, x1, y1, r, fill)`, `P.arc(...)`
- `P.text((x, y), s, size, color, fnt, anchor, rot)`
- `P.tag(cx, cy, text, p, color, size, rot, shake)` — hand-drawn label that pops in (`p` 0..1).
- `P.bubble(cx, cy, text, p, size, tail)` — speech bubble.
- `P.qmark(cx, cy, p, size)`, `P.speedlines(cx, cy, r0, r1)`, `P.arrow(x0, y0, x1, y1)`, `P.patch(x0, y0, x1, y1)` (paper-coloured cover).

Cast (cut-out sprites, `cutout.py`)
- `SPRITES = load_sprites(folder)` — every PNG in the folder (white background) becomes a transparent sprite, cached in `folder/_cut/`.
- `HERO = Actor(SPRITES, height=500)` — on-screen height in px at scale 1.
- `HERO.draw(P, x, y, scale, "pose-name", t, flip=False, rot=0, bob=True, squash=0, shadow=True, alpha=1)` — feet at (x, y). Swap `pose-name` over time to act; move `x` with `kf` to walk; `squash` on landings.
- Make poses with any image model using your character sheet as the reference image (prompts/poses.md). Never flip a sprite with text on it; generate the mirrored pose instead.

Props
- `chart_line`, `monitor_chart(P, box, prog, dive)`, `clock_hands`, `cone`, `timer`, `bug`, `coin`, `seesaw`, `crate`.

SHOTS entry
```python
"hook": dict(
    bg="desk",                       # bg/desk.png
    fn=shot_hook,
    cam=[(0, 960, 540, 1.0), (0.5, 600, 480, 1.6)],   # (u, cx, cy, zoom)
    sfx=[(0.05, "pop"), (0.5, "stamp")],              # (u, kind): pop stamp thud whoosh swish tick rise click done
    shake=[(0.5, 14, 0.4)],                            # (u, amplitude px, seconds)
)
```

Render
```
python scripttoon/toon.py STORYBOARD.md shots.py --stills        # 3 PNGs per shot at u = .25 .6 .9
python scripttoon/toon.py STORYBOARD.md shots.py                 # full render -> out/final.mp4
python scripttoon/toon.py STORYBOARD.md shots.py --redo 2        # re-render shot 2 only, reuse the rest
```
