"""ScriptToon: hand-drawn reenactment videos from a Markdown storyboard + a shots module (characters, props, camera, SFX in code).

    python scripttoon/toon.py examples/demo/STORYBOARD.md examples/demo/shots.py [--out ...] [--shots 1,2] [--stills] [--redo 1,2]

shots.py defines SHOTS (key -> dict(bg, fn, cam, sfx, shake)) and may set BG_DIR.
Backgrounds: <project>/bg/<key>.png (1920x1080 sketches; see prompts/backgrounds.md). Work/out: <project>/out/.
"""
import argparse
import asyncio
import json
import math
import random
import re
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1920, 1080
FPS = 30
PAD = 0.6
INK = (28, 24, 22)
PAPER = (252, 251, 247)
SKIN = (255, 226, 196)
MINT = (178, 230, 210)
YEL = (255, 222, 60)
RED = (220, 50, 40)
GREEN = (40, 150, 80)
BLUE = (60, 110, 200)
FONTS = Path("C:/Windows/Fonts")
F_HAND = FONTS / "segoeprb.ttf"      # handwriting bold
F_HAND_R = FONTS / "segoepr.ttf"
F_MONO = FONTS / "consola.ttf"

_fonts = {}
def font(path, size):
    k = (str(path), int(size))
    if k not in _fonts:
        _fonts[k] = ImageFont.truetype(str(path), int(size))
    return _fonts[k]


# ----------------------------------------------------------------------------- math
def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))

def ease(t):
    t = clamp(t)
    return t * t * (3 - 2 * t)

def ease_out(t):
    t = clamp(t)
    return 1 - (1 - t) ** 3

def overshoot(t):
    t = clamp(t)
    return 1 + 2.7 * (t - 1) ** 3 + 1.7 * (t - 1) ** 2  # back-out

def seg(u, a, b):
    """0..1 progress of u inside [a, b]."""
    if b <= a:
        return 1.0 if u >= a else 0.0
    return clamp((u - a) / (b - a))

def kf(keys, u):
    """keys: [(u, (v...)), ...] -> interpolated tuple with smoothstep."""
    if u <= keys[0][0]:
        return keys[0][1]
    for (u0, v0), (u1, v1) in zip(keys, keys[1:]):
        if u <= u1:
            p = ease(seg(u, u0, u1))
            return tuple(a + (b - a) * p for a, b in zip(v0, v1))
    return keys[-1][1]


# ----------------------------------------------------------------------------- pen helpers
class Pen:
    """Draws on a frame with a boiling hand-drawn line. `boil` changes every 3 frames."""
    def __init__(self, im: Image.Image, frame: int):
        self.im = im
        self.d = ImageDraw.Draw(im)
        self.rng = random.Random(frame // 3)
        self.frame = frame

    def w(self, pts, amp=2.0):
        return [(x + self.rng.uniform(-amp, amp), y + self.rng.uniform(-amp, amp)) for x, y in pts]

    def line(self, pts, width=6, color=INK, amp=2.0):
        pts = self.w(pts, amp)
        self.d.line(pts, fill=color, width=int(width), joint="curve")
        r = width / 2
        for x, y in (pts[0], pts[-1]):
            self.d.ellipse([x - r, y - r, x + r, y + r], fill=color)

    def poly(self, pts, fill=None, width=6, color=INK, amp=2.0):
        pts = self.w(pts, amp)
        if fill is not None:
            self.d.polygon(pts, fill=fill)
        self.d.line(pts + [pts[0]], fill=color, width=int(width), joint="curve")

    def circle(self, cx, cy, r, fill=None, width=6, color=INK, amp=1.5, n=28):
        pts = [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]
        self.poly(pts, fill=fill, width=width, color=color, amp=amp)

    def rrect(self, x0, y0, x1, y1, r=18, fill=None, width=6, color=INK, amp=2.0):
        pts = []
        for cx, cy, a0 in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
            for i in range(6):
                a = math.radians(a0 + 90 * i / 5)
                pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        self.poly(pts, fill=fill, width=width, color=color, amp=amp)

    def arc(self, cx, cy, r, a0, a1, width=6, color=INK, n=14, amp=1.5):
        pts = [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]
        self.line(pts, width=width, color=color, amp=amp)

    def text(self, xy, s, size=44, color=INK, fnt=F_HAND, anchor="la", rot=0.0):
        f = font(fnt, size)
        if abs(rot) < 0.5:
            self.d.text(xy, s, font=f, fill=color, anchor=anchor)
            return
        bbox = self.d.textbbox((0, 0), s, font=f)
        tw, th = bbox[2] - bbox[0] + 8, bbox[3] - bbox[1] + 8
        layer = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        ImageDraw.Draw(layer).text((4 - bbox[0], 4 - bbox[1]), s, font=f, fill=color + (255,))
        layer = layer.rotate(rot, expand=True, resample=Image.BICUBIC)
        x, y = xy
        self.im.paste(layer, (int(x - layer.width / 2), int(y - layer.height / 2)), layer)

    def tag(self, cx, cy, s, p=1.0, color=INK, fill=PAPER, size=42, rot=-3.0, shake=0.0):
        """Hand-drawn label box popping in (p 0..1 with overshoot)."""
        if p <= 0:
            return
        sc = overshoot(p) if p < 1 else 1.0
        f = font(F_HAND, size)
        bbox = self.d.textbbox((0, 0), s, font=f)
        tw, th = (bbox[2] - bbox[0]) * sc, (bbox[3] - bbox[1]) * sc
        px, py = 22 * sc, 14 * sc
        if shake:
            cx += self.rng.uniform(-shake, shake); cy += self.rng.uniform(-shake, shake)
        self.rrect(cx - tw / 2 - px, cy - th / 2 - py, cx + tw / 2 + px, cy + th / 2 + py, r=12, fill=fill, width=5, color=INK, amp=1.5)
        if sc >= 0.98:
            self.text((cx, cy), s, size=size, color=color, anchor="mm", rot=rot)
        else:
            self.text((cx, cy), s, size=max(8, size * sc), color=color, anchor="mm", rot=rot)

    def bubble(self, cx, cy, s, p=1.0, size=40, tail=(0, 60)):
        if p <= 0:
            return
        sc = overshoot(p) if p < 1 else 1.0
        f = font(F_HAND_R, size)
        bbox = self.d.textbbox((0, 0), s, font=f)
        tw, th = (bbox[2] - bbox[0]) * sc + 50, (bbox[3] - bbox[1]) * sc + 36
        self.rrect(cx - tw / 2, cy - th / 2, cx + tw / 2, cy + th / 2, r=26, fill=PAPER, width=5)
        tx, ty = cx + tail[0], cy + th / 2 + tail[1]
        self.poly([(cx - 18, cy + th / 2 - 4), (cx + 18, cy + th / 2 - 4), (tx, ty)], fill=PAPER, width=5)
        self.d.line([(cx - 18, cy + th / 2 - 2), (cx + 18, cy + th / 2 - 2)], fill=PAPER, width=8)
        if sc > 0.5:
            self.text((cx, cy), s, size=size * sc, fnt=F_HAND_R, anchor="mm")

    def qmark(self, cx, cy, p, size=90, color=INK):
        if p <= 0:
            return
        sc = overshoot(p) if p < 1 else 1.0
        self.text((cx, cy), "?", size=size * sc, color=color, anchor="mm", rot=self.rng.uniform(-8, 8))

    def speedlines(self, cx, cy, r0, r1, n=10, width=4):
        for i in range(n):
            a = self.rng.uniform(0, 2 * math.pi)
            self.line([(cx + r0 * math.cos(a), cy + r0 * math.sin(a)), (cx + r1 * math.cos(a), cy + r1 * math.sin(a))], width=width)

    def arrow(self, x0, y0, x1, y1, width=7, color=INK):
        self.line([(x0, y0), (x1, y1)], width=width, color=color)
        a = math.atan2(y1 - y0, x1 - x0)
        for s in (-1, 1):
            b = a + s * math.radians(150)
            self.line([(x1, y1), (x1 + 26 * math.cos(b), y1 + 26 * math.sin(b))], width=width, color=color)

    def patch(self, x0, y0, x1, y1):
        self.d.rectangle([x0, y0, x1, y1], fill=PAPER)


# ----------------------------------------------------------------------------- characters
# ----------------------------------------------------------------------------- props
def chart_line(P, x0, y0, x1, y1, prog, seed=3, color=INK, width=5, dive_at=None):
    """A wobbly price line inside a box drawn left->right up to prog (0..1)."""
    rng = random.Random(seed)
    n = 40
    pts = []
    v = 0.5
    for i in range(n + 1):
        v += rng.uniform(-0.12, 0.13)
        v = clamp(v, 0.1, 0.9)
        if dive_at is not None and i / n > dive_at:
            v = clamp(v - 0.09 * (i / n - dive_at) * 10, 0.05, 0.9)
        pts.append((x0 + (x1 - x0) * i / n, y1 - (y1 - y0) * v))
    k = max(2, int(len(pts) * clamp(prog)))
    P.line(pts[:k], width=width, color=color, amp=1.5)
    return pts[k - 1]


def clock_hands(P, cx, cy, r, hour_angle, minute_angle):
    for ang, ln, w in ((hour_angle, r * 0.55, 12), (minute_angle, r * 0.82, 8)):
        a = math.radians(ang - 90)
        P.line([(cx, cy), (cx + ln * math.cos(a), cy + ln * math.sin(a))], width=w)
    P.circle(cx, cy, 12, fill=INK, width=3)


def cone(P, x, y, s=1.0, knocked=False):
    if knocked:
        P.poly([(x - 30 * s, y), (x + 60 * s, y - 20 * s), (x + 70 * s, y + 2 * s), (x - 30 * s, y + 18 * s)], fill=(255, 140, 50), width=5 * s)
    else:
        P.poly([(x - 28 * s, y), (x + 28 * s, y), (x + 8 * s, y - 70 * s), (x - 8 * s, y - 70 * s)], fill=(255, 140, 50), width=5 * s)


def timer(P, cx, cy, r, prog, p=1.0):
    if p <= 0:
        return
    sc = overshoot(p) if p < 1 else 1
    r = r * sc
    P.circle(cx, cy, r, fill=PAPER, width=6)
    P.rrect(cx - 16, cy - r - 22, cx + 16, cy - r + 2, r=6, fill=INK, width=3)
    for i in range(12):
        a = math.radians(i * 30 - 90)
        P.line([(cx + r * 0.82 * math.cos(a), cy + r * 0.82 * math.sin(a)), (cx + r * 0.95 * math.cos(a), cy + r * 0.95 * math.sin(a))], width=4)
    a = math.radians(prog * 360 - 90)
    P.line([(cx, cy), (cx + r * 0.75 * math.cos(a), cy + r * 0.75 * math.sin(a))], width=7, color=RED)
    P.text((cx, cy + r * 0.45), "15 min", size=r * 0.32, anchor="mm")


def bug(P, x, y, s=1.0, t=0.0):
    wig = math.sin(t * 20) * 4 * s
    P.d.ellipse([x - 22 * s, y - 14 * s, x + 22 * s, y + 14 * s], fill=INK)
    P.circle(x + 26 * s, y, 10 * s, fill=INK, width=2)
    for i in range(3):
        for side in (-1, 1):
            lx = x - 12 * s + i * 12 * s
            P.line([(lx, y), (lx + wig * side, y + side * 24 * s)], width=3 * s)


def coin(P, cx, cy, r, text, spin=0.0, p=1.0):
    if p <= 0:
        return
    rx = max(2, r * abs(math.cos(spin)))
    P.d.ellipse([cx - rx, cy - r, cx + rx, cy + r], fill=YEL, outline=INK, width=5)
    if rx > r * 0.6:
        P.text((cx, cy), text, size=r * 0.7, anchor="mm")


def seesaw(P, px, py, half, angle_deg, left_txt, right_txt, p=1.0):
    a = math.radians(angle_deg)
    lx, ly = px - half * math.cos(a), py + half * math.sin(a)
    rx, ry = px + half * math.cos(a), py - half * math.sin(a)
    P.poly([(px - 50, py + 120), (px + 50, py + 120), (px, py)], fill=(200, 170, 120), width=6)
    P.line([(lx, ly), (rx, ry)], width=22, color=(200, 170, 120))
    P.line([(lx, ly), (rx, ry)], width=8)
    if left_txt:
        P.tag(lx + 40, ly - 60, left_txt, p=p, size=34, rot=-angle_deg)
    if right_txt:
        P.tag(rx - 40, ry - 60, right_txt, p=p, size=34, rot=-angle_deg)


def crate(P, x, y, s, text, p=1.0):
    if p <= 0:
        return
    P.rrect(x - 70 * s, y - 110 * s, x + 70 * s, y, r=8, fill=(222, 196, 150), width=6)
    P.line([(x - 70 * s, y - 55 * s), (x + 70 * s, y - 55 * s)], width=4)
    P.text((x, y - 55 * s), text, size=30 * s, anchor="mm")


def monitor_chart(P, box, prog, dive=None, seed=3):
    x0, y0, x1, y1 = box
    P.patch(x0, y0, x1, y1)
    P.rrect(x0, y0, x1, y1, r=6, fill=(246, 246, 240), width=5, amp=1)
    for i in range(1, 4):
        P.d.line([x0, y0 + (y1 - y0) * i / 4, x1, y0 + (y1 - y0) * i / 4], fill=(215, 215, 210), width=2)
    return chart_line(P, x0 + 20, y0 + 20, x1 - 20, y1 - 20, prog, seed=seed, color=(30, 110, 60) if dive is None else RED, width=6, dive_at=dive)


# ----------------------------------------------------------------------------- audio
async def tts(text, voice, out: Path):
    import edge_tts
    await edge_tts.Communicate(text, voice, rate="-2%").save(str(out))

def duration(path: Path) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)], capture_output=True, text=True, check=True)
    return float(json.loads(r.stdout)["format"]["duration"])

def loudness(mp3: Path, fps: int, sr=16000):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(mp3), "-f", "s16le", "-ac", "1", "-ar", str(sr), "-"], capture_output=True, check=True).stdout
    x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    n = sr // fps
    frames = len(x) // n
    rms = np.sqrt((x[:frames * n].reshape(frames, n) ** 2).mean(axis=1))
    lvl = np.clip(rms / (np.percentile(rms, 92) or 1.0), 0, 1)
    return np.convolve(lvl, [0.25, 0.5, 0.25], mode="same")

def sfx_track(events, total, rate=48000, volume=0.9):
    rng = np.random.default_rng(31)
    fx = np.zeros(int(total * rate) + rate, dtype=np.float32)
    for at, kind in events:
        dur = {'click': .075, 'whoosh': .22, 'pop': .16, 'done': .48, 'thud': .18, 'stamp': .55, 'swish': .35, 'tick': .03, 'rise': .4}[kind]
        t = np.arange(round(dur * rate)) / rate
        if kind == 'click': v = (.065 * np.sin(2 * np.pi * 1850 * t) + .027 * rng.normal(size=len(t))) * np.exp(-t * 65)
        elif kind == 'whoosh': v = .058 * np.convolve(rng.normal(size=len(t)), np.ones(9) / 9, mode='same') * np.sin(np.pi * t / dur) ** 2
        elif kind == 'pop': v = .075 * np.sin(2 * np.pi * (440 * t - 600 * t * t)) * np.exp(-t * 22)
        elif kind == 'thud': v = (.16 * np.sin(2 * np.pi * (150 * t - 180 * t * t)) + .05 * np.convolve(rng.normal(size=len(t)), np.ones(25) / 25, mode='same')) * np.exp(-t * 30)
        elif kind == 'stamp': v = (.30 * np.sin(2 * np.pi * (95 * t - 60 * t * t)) + .14 * np.convolve(rng.normal(size=len(t)), np.ones(5) / 5, mode='same') * np.exp(-t * 18)) * np.exp(-t * 7)
        elif kind == 'swish': v = .07 * np.convolve(rng.normal(size=len(t)), np.ones(4) / 4, mode='same') * np.sin(np.pi * t / dur) ** 3 * (1 + np.sin(2 * np.pi * 12 * t)) / 2
        elif kind == 'tick': v = .05 * np.sin(2 * np.pi * 2600 * t) * np.exp(-t * 220)
        elif kind == 'rise': v = .05 * np.sin(2 * np.pi * (500 * t + 900 * t * t)) * np.sin(np.pi * t / dur)
        else: v = .045 * (np.sin(2 * np.pi * 784 * t) + .5 * np.sin(2 * np.pi * 1175 * t)) * np.exp(-t * 8) * np.minimum(1, t * 100)
        i = int(max(0, at) * rate)
        k = min(len(v), len(fx) - i)
        if k > 0:
            fx[i:i + k] += v[:k] * volume
    return fx


# ----------------------------------------------------------------------------- render
def parse_storyboard(path: Path):
    text = path.read_text(encoding="utf-8")
    shots = []
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        head, _, body = block.partition("\n")
        m = re.match(r"(\d+)\.\s*([\w-]+)", head.strip())
        if not m:
            continue
        narr = re.search(r"^NARRATION:\s*(.*)$", body, flags=re.M)
        shots.append(dict(num=int(m.group(1)), key=m.group(2), narration=narr.group(1).strip() if narr else ""))
    return shots


def camera(frame: Image.Image, cx, cy, zoom, shake=0.0, rng=None):
    if shake and rng:
        cx += rng.uniform(-shake, shake); cy += rng.uniform(-shake, shake)
    w, h = W / zoom, H / zoom
    x0 = clamp(cx - w / 2, 0, W - w); y0 = clamp(cy - h / 2, 0, H - h)
    if zoom <= 1.001 and abs(x0) < 1 and abs(y0) < 1:
        return frame
    return frame.crop((int(x0), int(y0), int(x0 + w), int(y0 + h))).resize((W, H), Image.BILINEAR)


def render_shot(shot, spec, mp3, work, fps, bgs):
    speak = duration(mp3)
    dur = speak + PAD
    n = int(round(dur * fps))
    L = loudness(mp3, fps)
    bg = bgs[spec["bg"]]
    out = work / f"toon-{shot['num']:02d}.mp4"
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps), "-i", "-",
                           "-i", str(mp3), "-af", f"apad=pad_dur={PAD}", "-t", f"{dur:.3f}", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                           "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "160k", "-ar", "48000", str(out)], stdin=subprocess.PIPE)
    cam = [(k[0], (k[1], k[2], k[3])) for k in spec["cam"]]
    shakes = spec.get("shake", [])
    rng = random.Random(shot["num"])
    blinks = []
    tb = rng.uniform(1.5, 3.0)
    while tb < dur:
        blinks.append(tb); tb += rng.uniform(2.0, 4.0)
    for f in range(n):
        t = f / fps
        u = clamp(t / speak)
        frame = bg.copy()
        P = Pen(frame, f)
        lvl = float(L[f]) if f < len(L) else 0.0
        P.blink = any(abs(t - b) < 0.08 for b in blinks)
        spec["fn"](P, u, t, lvl)
        cx, cy, z = kf(cam, u)
        sh = 0.0
        for su, amp, sd in shakes:
            st = su * speak
            if st <= t < st + sd:
                sh = amp * (1 - (t - st) / sd)
        frame = camera(frame, cx, cy, z, sh, P.rng)
        ff.stdin.write(frame.tobytes())
    ff.stdin.close(); ff.wait()
    if ff.returncode:
        raise SystemExit(f"ffmpeg failed on shot {shot['num']}")
    return out, dur, speak


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("storyboard")
    ap.add_argument("shots_module")
    ap.add_argument("--out", default="")
    ap.add_argument("--work", default="")
    ap.add_argument("--voice", default="en-US-AndrewNeural")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--shots", default="")
    ap.add_argument("--redo", default="", help="re-render only these shot numbers, reuse the other clips")
    ap.add_argument("--stills", action="store_true", help="write PNGs at u=0.25/0.6/0.9 per shot, no video")
    a = ap.parse_args()
    import importlib.util
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    spec_ = importlib.util.spec_from_file_location("shots", Path(a.shots_module).resolve())
    mod = importlib.util.module_from_spec(spec_); spec_.loader.exec_module(mod)
    SHOTS = mod.SHOTS
    slug = Path(a.storyboard).resolve().parent.name
    base = Path(a.storyboard).resolve().parent / "out"
    BG_DIR = Path(getattr(mod, "BG_DIR", Path(a.storyboard).resolve().parent / "bg"))
    out = Path(a.out).expanduser() if a.out else base / "final.mp4"
    work = Path(a.work).expanduser() if a.work else base / "toon-work"
    work.mkdir(parents=True, exist_ok=True)
    shots = parse_storyboard(Path(a.storyboard))
    only = {int(x) for x in a.shots.split(",") if x.strip()}
    bgs = {k: Image.open(BG_DIR / f"{k}.png").convert("RGB").resize((W, H)) for k in {s["bg"] for s in SHOTS.values()}}
    parts, events, clock = [], [], 0.0
    for sh in shots:
        if only and sh["num"] not in only:
            continue
        spec = SHOTS[sh["key"]]
        if a.stills:
            for u in (0.25, 0.6, 0.9):
                frame = bgs[spec["bg"]].copy()
                P = Pen(frame, int(u * 100)); P.blink = False
                spec["fn"](P, u, u * 10, 0.5)
                cx, cy, z = kf([(k[0], (k[1], k[2], k[3])) for k in spec["cam"]], u)
                camera(frame, cx, cy, z).save(work / f"still-{sh['num']:02d}-{int(u * 100)}.png")
            print("stills", sh["num"], sh["key"]); continue
        mp3 = work / f"n{sh['num']:02d}.mp3"
        if not mp3.exists():
            asyncio.run(tts(sh["narration"], a.voice, mp3))
        redo = {int(x) for x in a.redo.split(",") if x.strip()}
        existing = work / f"toon-{sh['num']:02d}.mp4"
        if a.redo and sh["num"] not in redo and existing.exists():
            speak = duration(mp3); dur = speak + PAD; clip = existing
        else:
            clip, dur, speak = render_shot(sh, spec, mp3, work, a.fps, bgs)
        for su, kind in spec["sfx"]:
            events.append((clock + su * speak, kind))
        clock += dur
        parts.append(clip)
        print(f"  shot {sh['num']:02d} {sh['key']:14s} {dur:5.1f}s", flush=True)
    if a.stills or not parts:
        return
    lst = work / "concat.txt"
    lst.write_text("".join(f"file '{p.as_posix()}'\n" for p in parts), encoding="utf-8")
    silent = work / "video-novoice-sfx.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(silent)], check=True)
    fx = sfx_track(events, clock)
    sfx = work / "sfx.wav"
    with wave.open(str(sfx), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(48000); w.writeframes((np.clip(fx, -1, 1) * 32767).astype("<i2").tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(sfx), "-filter_complex",
                    "[0:a][1:a]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=11[a]", "-map", "0:v", "-map", "[a]",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", str(out)], check=True)
    print(f"done: {out}  {duration(out):.1f}s  sfx events {len(events)}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
