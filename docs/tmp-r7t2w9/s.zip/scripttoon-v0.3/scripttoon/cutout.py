"""Cut-out characters for the WIT engine: sprites generated from the character sheet, animated by transforms.

Sprites: PNGs on white (AI-generated with the sheet as reference) in <sprites_dir>/<name>.png.
`load_sprites(dir)` removes the white background once and caches RGBA + the feet anchor (bottom-centre of the
opaque area). `Actor.draw(P, x, y, scale, pose, t, ...)` pastes a pose at feet (x, y) with idle bob, optional
squash/stretch, flip, rotation and a ground shadow, so a character can walk in, land, react and leave.
"""
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

_cache = {}


def _cutout(path: Path) -> Image.Image:
    """White background -> alpha, with a soft edge; trims to the opaque bbox."""
    im = Image.open(path).convert("RGB")
    a = np.asarray(im).astype(np.int16)
    # distance from white; lines/colours are far from white, paper is ~255
    d = 255 - a.min(axis=2)
    alpha = np.clip((d - 18) * 6, 0, 255).astype(np.uint8)  # 18..60 ramps 0..255
    rgba = Image.fromarray(np.dstack([np.asarray(im), alpha]), "RGBA")
    # fill interior: anything enclosed by lines should be opaque even if white (eyes, teeth)
    mask = Image.fromarray(alpha).filter(ImageFilter.MaxFilter(9))
    from PIL import ImageDraw
    bbox = mask.getbbox()
    if not bbox:
        return rgba
    # flood the outside from the corners on the dilated mask, everything else is interior
    m = np.asarray(mask) > 0
    h, w = m.shape
    outside = np.zeros_like(m)
    stack = [(0, 0), (0, w - 1), (h - 1, 0), (h - 1, w - 1)]
    seen = np.zeros_like(m)
    from collections import deque
    dq = deque(stack)
    while dq:
        y, x = dq.popleft()
        if seen[y, x] or m[y, x]:
            continue
        seen[y, x] = True
        outside[y, x] = True
        if y > 0: dq.append((y - 1, x))
        if y < h - 1: dq.append((y + 1, x))
        if x > 0: dq.append((y, x - 1))
        if x < w - 1: dq.append((y, x + 1))
    interior = ~outside
    alpha2 = np.where(interior, 255, alpha).astype(np.uint8)
    # soften the outer edge a little
    alpha_im = Image.fromarray(alpha2).filter(ImageFilter.GaussianBlur(0.8))
    rgba.putalpha(alpha_im)
    return rgba.crop(rgba.getbbox())


def load_sprites(sprites_dir: Path):
    sprites_dir = Path(sprites_dir)
    key = str(sprites_dir)
    if key in _cache:
        return _cache[key]
    out = {}
    cache_dir = sprites_dir / "_cut"
    cache_dir.mkdir(exist_ok=True)
    for p in sorted(sprites_dir.glob("*.png")):
        c = cache_dir / p.name
        if c.exists() and c.stat().st_mtime >= p.stat().st_mtime:
            im = Image.open(c).convert("RGBA")
        else:
            im = _cutout(p)
            im.save(c)
        out[p.stem] = im
    _cache[key] = out
    return out


class Actor:
    """A cut-out character. `height` = on-screen height in px at scale 1 (feet to top of head)."""

    def __init__(self, sprites: dict, height=520):
        self.sprites = sprites
        self.height = height

    def draw(self, P, x, y, scale=1.0, pose="idle", t=0.0, flip=False, rot=0.0, bob=True, squash=0.0, shadow=True, alpha=1.0):
        im = self.sprites.get(pose) or next(iter(self.sprites.values()))
        s = self.height * scale / im.height
        w, h = int(im.width * s), int(im.height * s)
        if bob:
            # breathing: tiny vertical scale wobble, feet stay planted
            h = int(h * (1 + 0.012 * math.sin(t * 2.4)))
        if squash:
            w, h = int(w * (1 + squash)), int(h * (1 - squash))
        spr = im.resize((max(1, w), max(1, h)), Image.LANCZOS)
        if flip:
            spr = spr.transpose(Image.FLIP_LEFT_RIGHT)
        if abs(rot) > 0.1:
            spr = spr.rotate(rot, resample=Image.BICUBIC, expand=True)
        if alpha < 1:
            a = spr.getchannel("A").point(lambda v: int(v * alpha))
            spr.putalpha(a)
        if shadow:
            sw = int(w * 0.55)
            P.d.ellipse([x - sw // 2, y - 10, x + sw // 2, y + 10], fill=(0, 0, 0, 40) if P.im.mode == "RGBA" else (214, 212, 206))
        P.im.paste(spr, (int(x - spr.width / 2), int(y - spr.height)), spr)
        return spr.width, spr.height
