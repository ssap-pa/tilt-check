# Shot API

A shot function receives `(P, u, t, L)`:
- `P` — a `Pen` bound to this frame (1920×1080). All drawing goes through it so lines "boil" like hand-drawn animation.
- `u` — progress through the narration, 0..1.
- `t` — seconds since the shot started.
- `L` — narration loudness this frame, 0..1 (drives the robot's mouth).

Timing helpers
- `seg(u, a, b)` → 0..1 progress of `u` inside `[a, b]`. Use it as the `p` of anything that pops in.
- `kf([(u0, (x,)), (u1, (x,))], u)` → smooth interpolation between keyframes (any tuple length).
- `ease`, `ease_out`, `overshoot` → curves.

Pen
- `P.line(points, width, color)`, `P.poly(points, fill)`, `P.circle(cx, cy, r, fill)`, `P.rrect(x0, y0, x1, y1, r, fill)`, `P.arc(...)`
- `P.text((x, y), s, size, color, fnt, anchor, rot)`
- `P.tag(cx, cy, text, p, color, size, rot, shake)` — hand-drawn label that pops in (`p` 0..1).
- `P.bubble(cx, cy, text, p, size, tail)` — speech bubble.
- `P.qmark(cx, cy, p, size)`, `P.speedlines(cx, cy, r0, r1)`, `P.arrow(x0, y0, x1, y1)`, `P.patch(x0, y0, x1, y1)` (paper-coloured cover).

Cast
- `draw_person(P, x, y, s, pose, t, mouth)` — feet at (x, y). pose keys: `facing` ±1, `sit`, `larm`/`rarm` (degrees), `eyes` open/closed/wide/sad/happy, `mouth` smile/flat/open/frown, `brows` none/sad/angry, `lean`, `bob`, `hands_face`.
- `draw_tick(P, x, y, s, pose, t, mouth, blink)` — the robot. poses: idle, wave, point, pointr, surprised, facepalm, thumbs, shrug, hold. Pass `L` as `mouth` for lip-sync.
- Add your own character the same way: a function that draws with `P` at a feet position, reading a pose dict.

Props
- `chart_line`, `monitor_chart(P, box, prog, dive)`, `clock_hands`, `cone`, `timer`, `bug`, `coin`, `seesaw`, `crate`.

SHOTS entry
```python
"hook": dict(
    bg="desk",                       # bg/desk.png
    fn=shot_hook,
    cam=[(0, 960, 540, 1.0), (0.5, 600, 480, 1.6)],   # (u, cx, cy, zoom)
    sfx=[(0.05, "pop"), (0.5, "stamp")],              # (u, kind): pop stamp thud whoosh swish tick rise click done
    shake=[(0.5, 14, 0.4)],                            # (u, amplitude px, seconds)
)
```

Render
```
python scripttoon/toon.py STORYBOARD.md shots.py --stills        # 3 PNGs per shot at u = .25 .6 .9
python scripttoon/toon.py STORYBOARD.md shots.py                 # full render -> out/final.mp4
python scripttoon/toon.py STORYBOARD.md shots.py --redo 2        # re-render shot 2 only, reuse the rest
```
