"""Demo shots for ScriptToon. Run: python scripttoon/toon.py examples/demo/STORYBOARD.md examples/demo/shots.py"""
import math
from toon import *  # noqa: F401,F403

MON = (300, 300, 720, 620)      # monitor box on desk.png
CHAIR = (1230, 980)             # feet of the person sitting on the chair
DESK_TOP = (880, 640)           # where the robot stands on the desk
NOTE_L = (434, 216, 888, 950)   # left notebook page
NOTE_R = (910, 216, 1384, 950)
SIT = dict(sit=True, facing=-1, larm=28, rarm=32, mouth="flat", bob=False)


def shot_hook(P, u, t, L):
    x0, y0, x1, y1 = MON
    P.patch(x0, y0, x1, y1)
    P.rrect(x0, y0, x1, y1, r=6, fill=(246, 246, 240), width=5, amp=1)
    for i in range(12):
        at = 0.05 + i * 0.03
        P.tag(x0 + 70 + (i % 4) * 95, y0 + 60 + (i // 4) * 90, f"btn {i + 1}", p=seg(u, at, at + 0.05), size=22)
    if u > 0.5:
        pr = seg(u, 0.5, 0.58)
        P.line([(x0 + 30, y0 + 30), (x0 + 30 + (x1 - x0 - 60) * pr, y0 + 30 + (y1 - y0 - 60) * pr)], width=12, color=RED)
        P.line([(x1 - 30, y0 + 30), (x1 - 30 - (x1 - x0 - 60) * pr, y0 + 30 + (y1 - y0 - 60) * pr)], width=12, color=RED)
    P.tag(1000, 300, "sign-ups ×2", p=seg(u, 0.62, 0.7), size=60, color=GREEN, rot=-4)
    draw_person(P, CHAIR[0], CHAIR[1], 1.0, dict(SIT, eyes="wide" if u > 0.5 else "open", mouth="open" if u > 0.5 else "flat"), t)
    draw_tick(P, DESK_TOP[0], DESK_TOP[1], 0.9, "point", t, L)


def shot_three(P, u, t, L):
    x0, y0, x1, y1 = NOTE_L
    for i, (s_, at) in enumerate((("Add", 0.05), ("Done", 0.25), ("Snooze", 0.45))):
        p = seg(u, at, at + 0.07)
        if p > 0:
            P.text((x0 + 60, y0 + 160 + i * 130), s_[: max(1, int(len(s_) * p))], size=64, fnt=F_HAND_R)
    draw_tick(P, NOTE_R[0] + 240, NOTE_R[3] - 40, 0.75, "pointr", t, L)
    P.tag(NOTE_R[0] + 240, NOTE_R[1] + 140, "settings nobody opened twice", p=seg(u, 0.7, 0.78), size=30, rot=-3)


def shot_close(P, u, t, L):
    draw_person(P, 700, 1000, 1.0, dict(facing=1, larm=20, rarm=140 if u > 0.4 else 20, eyes="happy", mouth="smile"), t)
    draw_tick(P, 1150, 1010, 1.0, "thumbs" if u > 0.4 else "idle", t, L)
    P.tag(960, 300, "what did you delete?", p=seg(u, 0.55, 0.63), size=50, rot=-2)
    P.tag(960, 980, "link below", p=seg(u, 0.8, 0.88), size=40, rot=2)


SHOTS = {
    "hook":  dict(bg="desk", fn=shot_hook, cam=[(0, 760, 520, 1.3), (0.5, 600, 480, 1.6), (0.62, 900, 560, 1.2), (1, 900, 560, 1.2)],
                  sfx=[(0.05 + i * 0.03, "pop") for i in range(12)] + [(0.5, "stamp"), (0.62, "rise")], shake=[(0.5, 14, 0.4)]),
    "three": dict(bg="notebook", fn=shot_three, cam=[(0, 900, 560, 1.15), (0.2, 760, 600, 1.4), (1, 760, 600, 1.4)],
                  sfx=[(0.05, "tick"), (0.25, "tick"), (0.45, "tick"), (0.7, "pop")]),
    "close": dict(bg="park", fn=shot_close, cam=[(0, 960, 700, 1.25), (1, 960, 600, 1.0)],
                  sfx=[(0.4, "pop"), (0.55, "stamp"), (0.8, "done")]),
}
