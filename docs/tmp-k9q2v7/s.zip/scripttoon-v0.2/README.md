# ScriptToon — hand-drawn explainer videos from a Markdown storyboard

Write a storyboard. Get a 1080p cartoon with a reacting character, camera moves, sound effects and a synthetic voice. No video editor, no After Effects, no per-frame drawing. Everything after the storyboard is Python.

Two videos made with it (3–5 minutes each, rendered in under 10 minutes on a laptop):
- https://youtu.be/8LZYHxkD3Ew
- https://youtu.be/FdQCacLMjHg

## What you get
- `scripttoon/cutout.py` — cut-out characters from YOUR character sheet: generate poses with any image model using the sheet as the reference image (prompts included), drop the PNGs in a folder, and the module removes the white background, anchors the feet and animates them (idle breathing, squash on landing, flips, rotation, fades). This is how the WIT videos above are made.
- `scripttoon/toon.py` — the engine: storyboard parser, pen-line renderer (boiling outlines), a storyboard parser, pen-line props and labels, two placeholder cast members for blocking; props (tags, speech bubbles, charts, timers, seesaw, coins, cones); camera keyframes with shake; synthesized SFX (pop, stamp, thud, whoosh, swish, tick, rise, click, done) mixed under the voice; per-shot rendering with `--redo` so you only re-render what you changed.
- `examples/demo/` — a 40-second storyboard + shots file you can render right away, with three sketch backgrounds.
- `prompts/backgrounds.md` — the exact image-generation prompt that produces matching ink-sketch backgrounds (any image model), and how to pick anchor coordinates.
- `prompts/poses.md` — the pose prompt template that keeps a character consistent across 20 poses when you pass the sheet as the reference image.
- `docs/` — storyboard format, the shot API (`P.tag`, `P.bubble`, `draw_person`, `draw_tick`, `kf`, `seg`…), and a checklist for hooks, titles and thumbnails.

## Requirements
Python 3.10+, `pillow`, `numpy`, `edge-tts`, and `ffmpeg` on PATH. Windows fonts are referenced by default (Segoe Print, Arial, Consolas); on macOS/Linux point `F_HAND`, `F_HAND_R`, `F_MONO` at any handwriting/sans/mono TTF.

```bash
pip install pillow numpy edge-tts
python scripttoon/toon.py examples/demo/STORYBOARD.md examples/demo/shots.py --stills   # check frames
python scripttoon/toon.py examples/demo/STORYBOARD.md examples/demo/shots.py            # render
```

## How a video is made
1. **Storyboard** (`STORYBOARD.md`): one `## N. key` per shot with `NARRATION:` (what the voice says), `ACTION:` and `CAM:` as notes for yourself.
2. **Backgrounds**: one sketch per location at 1920×1080 in `bg/<key>.png`.
3. **Shots** (`shots.py`): a function per shot that draws characters and props for progress `u` (0..1 of the narration) and time `t`, plus a `SHOTS` dict with the background, camera keyframes, SFX cues and shakes.
4. Render. Narration is generated once per shot and cached; change a shot and re-render only that one with `--redo 3`.

## License
Single-user commercial license: use it for your own and your clients' videos without limit. Don't resell or redistribute the engine itself. See LICENSE.txt.

## Support
Reply to your receipt. If something in the engine doesn't do what this README says, you get a fix or a refund.
